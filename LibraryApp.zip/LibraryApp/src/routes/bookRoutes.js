
const express = require('express');

const booksRouter = express.Router();
function router(nav){

    var books = [
        {
            title : "Pride and Prejudice",
            author : "Jane Austen",
            genre : "Western Classic",
            img: "pandp.jpg"
        },
        {
            title : "Nineteen-Eighty-Four",
            author : "George Orwell",
            genre : "Dystopia",
            img: "1984.jpg"
        },
        {
            title : "The Lord of the Rings",
            author : "J.R.R Tolkien",
            genre : "Fantasy",
            img: "lord.jpg"
        },
        {
            title : "The Foundation Series",
            author : "Issac Asimov",
            genre : "Science Fiction",
            img: "foundation.jpg"
        },
        {
            title : "The Hunger Games",
            author : "Suzanne Collins",
            genre : "Fiction",
            img: "hunger.jpg"
        },
        {
            title : "Interpreter of Maladies",
            author : "Jhumpa Lahiri",
            genre : "Immigrant Experience",
            img: "interpreter.jpg"
        }
    
    ];
    
    booksRouter.get('/', function(req,res){
        res.render("books",
        {
            nav,
            title:'Library' ,
            books
        });
    });
    
    booksRouter.get('/:id', function(req,res){
        const id = req.params.id;
        res.render('book',
        {
            nav,
            title:'Library' ,
            book : books[id]
        });
    })
    
    return booksRouter;
}

module.exports = router;











