

let name = document.getElementById("name");
let mobile = document.getElementById("mobile");
let mail = document.getElementById("mail");
let pwd = document.getElementById("pwd");
let cpwd = document.getElementById("cpwd");
let strengthBar = document.getElementById("strength");

let errorName = document.getElementById("errorName");
let errorMob = document.getElementById("errorMob");
let errorMail = document.getElementById("errorMail");
let errorPwd = document.getElementById("errorPwd");
let errorCpwd = document.getElementById("errorCpwd");

let mailRegex = /^([A-Za-z0-9\.-]+)@([A-Za-z0-9\-]+)\.([a-z]{2,3})(\.[a-z{2,3}])?$/ ;
let mobRegex =/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;

// pwd.addEventListener("keyup",pwdVerify);

function validate(){
return ((verifyName()) || (verifyMobile()) || (verifyMail()) || (verifyPassword()) || (verifyConfirm()));

}


function verifyName(){
    if(name.value == ""){
        errorName.innerHTML = "Username is mandatory";
        errorName.style.color = "red";
        errorName.style.fontSize = "smaller";
        return false;
    } 
    else{
        errorName.innerHTML = " ";
    }
}
function verifyMobile(){
    if(mobile.value ==""){
       
        errorMob.innerHTML = "Mobile number is mandatory";
        errorMob.style.color = "red";
        errorMob.style.fontSize = "smaller";
        return false;
    }
    else if(mobRegex.test(mobile.value) == false){
        errorMob.innerHTML = "Mobile Number is Invalid";
        errorMob.style.color = "red";
        errorMob.style.fontSize = "smaller";
        return false;
    }
    else{
        errorMob.innerHTML = " ";
    }
}
function verifyMail(){
    
    if(mail.value == ""){
        errorMail.innerHTML = "Email id should not be blank";
        errorMail.style.color = "red";
        errorMail.style.fontSize = "smaller";
        return false;
    }
    else if(mailRegex.test(mail.value) == false){
        errorMail.innerHTML = "Email id is Invalid";
        errorMail.style.color = "red";
        errorMail.style.fontSize = "smaller";
        return false;
    }
    else{
        errorMail.innerHTML = "";
       
    }
}


function verifyPassword(){
    // alert("hi");
    if(pwd.value == ""){
        strengthBar.innerHTML = "Password is mandatory";
        strengthBar.style.color = "red";
        strengthBar.style.fontSize = "smaller";
        return false;
    } 
    var pwdRegex1 = /[a-zA-Z0-9]+/;
    var pwdRegex2 = /[~+()]/;
    var pwdRegex3 = /[@!#$%^&*]/;
    var strength = 0;
    
    if(pwd.value.match(pwdRegex1)){
        strength += 1;
    }
    if(pwd.value.match(pwdRegex2)){
        strength += 1;
    }
    if(pwd.value.match(pwdRegex3)){
        strength += 1;
    }
    if(pwd.value.length > 8){
        strength += 1;
    }
    switch(strength){
        case 0:
            strengthBar.value = 0;
            break;
        
        case 1:
            strengthBar.value = 20;
            strengthBar.innerHTML =" weak";
            strengthBar.style.color ="red";
            break;

        case 2:
            strengthBar.value = 40;
            strengthBar.innerHTML =" good";
            strengthBar.style.color ="orange";
            break;

        case 3:
            strengthBar.value = 60;
            strengthBar.innerHTML =" strong";
            strengthBar.style.color ="green";
            break;

        case 4:
            strengthBar.value = 80;
            strengthBar.innerHTML =" very strong";
            strengthBar.style.color ="darkgreen";
            break;
    }
}


function verifyConfirm(){
    if((cpwd.value != pwd.value) ||(cpwd.value == '')){
        errorCpwd.innerHTML = "Password should match and cannot be blank";
        errorCpwd.style.color = "red";
        errorCpwd.style.fontSize = "smaller";
        return false;
    }
}

