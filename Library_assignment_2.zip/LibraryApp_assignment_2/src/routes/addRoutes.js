
const express = require('express');

const addRoutes = express.Router();
function router(nav){
    
    addRoutes.get('/', function(req,res){
        res.render("add",
        {
            nav,
            title:'Library' 
        });
    });
  
    return addRoutes;
}

module.exports = router;











