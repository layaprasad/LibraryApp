
const express = require('express');

const authorRoutes = express.Router();
function router(nav){

    var authors = [
        {           
            author : "Jane Austen",           
            img: "jane.jpg"
        },
        {           
            author : "George Orwell",           
            img: "george.jpg"
        },
        {           
            author : "J.R.R Tolkiens",           
            img: "tolkien.jpg"
        },
        {
           
            author : "Suzanne Collins",
            img: "suzanne.jpg"
        },
        {           
            author : "Jhumpa Lahiri",            
            img: "jhumpa.jpg"
        }
    
    ];
    
    authorRoutes.get('/', function(req,res){
        res.render("authors",
        {
            nav,
            title:'Library' ,
            authors
        });
    });
    
    authorRoutes.get('/:id', function(req,res){
        const id = req.params.id;
        res.render('author',
        {
            nav,
            title:'Library' ,
            authors : authors[id]
        });
    })
    
    return authorRoutes;
}

module.exports = router;











