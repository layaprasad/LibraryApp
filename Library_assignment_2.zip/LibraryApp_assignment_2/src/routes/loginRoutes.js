
const express = require('express');

const loginRoutes = express.Router();
function router(nav){
 
    loginRoutes.get('/', function(req,res){
        res.render("login",
        {
            nav,
            title:'Library' 
            // login
        });
    });
    
   
    return loginRoutes;
}

module.exports = router;











